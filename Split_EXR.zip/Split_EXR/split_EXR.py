import nuke
import nukescripts

class LayerSplitPanel(nukescripts.PythonPanel):
    def __init__(self, read_node, layers):
        super(LayerSplitPanel, self).__init__('EXR Layer Split: Color & Utility')
        self.read_node = read_node
        self.main_knob = nuke.Enumeration_Knob('main_layers', 'Color Layers', layers)
        self.main_knob.setFlag(nuke.STARTLINE)
        self.tech_knob = nuke.Enumeration_Knob('tech_layers', 'Utility Layers', layers)
        self.tech_knob.setFlag(nuke.STARTLINE)
        self.main_input = nuke.Multiline_Eval_String_Knob('main_input', 'Color selected', '')
        self.tech_input = nuke.Multiline_Eval_String_Knob('tech_input', 'Utility selected', '')
        self.preview_button = nuke.PyScript_Knob('preview', '📷 Open Preview')

        self.addKnob(self.main_knob)
        self.addKnob(self.tech_knob)
        self.addKnob(self.main_input)
        self.addKnob(self.tech_input)
        self.addKnob(self.preview_button)

        self.main_knob.setTooltip("Select a layer and press Enter to add to Color")
        self.tech_knob.setTooltip("Select a layer and press Enter to add to Utility")

    def knobChanged(self, knob):
        if knob is self.main_knob:
            current = self.main_input.value().splitlines()
            selected = self.main_knob.value()
            if selected and selected not in current:
                self.main_input.setValue('\n'.join(current + [selected]))
        elif knob is self.tech_knob:
            current = self.tech_input.value().splitlines()
            selected = self.tech_knob.value()
            if selected and selected not in current:
                self.tech_input.setValue('\n'.join(current + [selected]))
        elif knob.name() == 'preview':
            existing = nuke.toNode('layer_preview')
            if existing:
                nuke.delete(existing)
            lcs = nuke.createNode('LayerContactSheet', inpanel=False)
            lcs.setName('layer_preview')
            lcs.setInput(0, self.read_node)
            lcs['showLayerNames'].setValue(True)
            lcs.setXYpos(self.read_node.xpos(), self.read_node.ypos() - 200)

def launch_layer_split_panel():
    read_node = nuke.selectedNode()
    if read_node.Class() != "Read":
        nuke.message("Select a Read node with EXR")
        return

    layers = [l for l in nuke.layers(read_node) if l not in ['rgba', 'rgb', 'alpha', 'other']]
    if not layers:
        nuke.message("No EXR layers found.")
        return

    panel = LayerSplitPanel(read_node, layers)
    if panel.showModalDialog():
        main = panel.main_input.value().splitlines()
        tech = panel.tech_input.value().splitlines()
        build_split_pipe(read_node, main, tech)

def build_split_pipe(node, main_layers, tech_layers):
    X = node.xpos()
    Y = node.ypos() + 200
    x_spacing = 250

    mainDot = nuke.createNode('Dot', inpanel=False)
    mainDot.setInput(0, node)
    mainDot.setXYpos(X + 30, Y)

    unpremult = nuke.createNode('Unpremult', inpanel=False)
    unpremult['channels'].setValue('all')
    unpremult.setInput(0, mainDot)
    unpremult.setXYpos(X, Y + 100)

    baseDot = nuke.createNode('Dot', inpanel=False)
    baseDot.setInput(0, unpremult)
    baseDot.setXYpos(X + 30, Y + 180)

    shuffle_black = nuke.createNode('Shuffle', inpanel=False)
    for ch in ('red', 'green', 'blue', 'alpha'):
        shuffle_black[ch].setValue('black')
    shuffle_black['label'].setValue('black')
    shuffle_black.setInput(0, baseDot)
    shuffle_black.setXYpos(X, Y + 300)

    remove_black = nuke.createNode('Remove', inpanel=False)
    remove_black['operation'].setValue('keep')
    remove_black['channels'].setValue('rgba')
    remove_black.setInput(0, shuffle_black)
    remove_black.setXYpos(X, Y + 400)

    black_dot = nuke.createNode('Dot', inpanel=False)
    black_dot.setInput(0, remove_black)
    y_merge = Y + 800
    black_dot.setXYpos(X + 30, y_merge )

    merge_chain = black_dot

    # MAIN LAYERS
    previous_dot = baseDot
    for i, layer in enumerate(main_layers):
        x = X + (i + 1) * x_spacing
        y = Y + 200

        dot = nuke.createNode('Dot', inpanel=False)
        dot.setInput(0, previous_dot)

        shuffle = nuke.createNode('Shuffle', inpanel=False)
        shuffle['in'].setValue(layer)
        shuffle['label'].setValue('[value in]')
        shuffle.setInput(0, dot)
        shuffle.setXYpos(x, y + 100)

        snap_dot_to_node(dot, shuffle)
        dot['label'].setValue(layer)
        dot['note_font_size'].setValue(41)
        dot['note_font_color'].setValue(0xFFFFFFFF)

        remove = nuke.createNode('Remove', inpanel=False)
        remove['operation'].setValue('keep')
        remove['channels'].setValue('rgba')
        remove.setInput(0, shuffle)
        remove.setXYpos(x, y + 200)

        merge = nuke.createNode('Merge2', inpanel=False)
        merge['operation'].setValue('plus')
        merge.setInput(0, merge_chain)
        merge.setInput(1, remove)
        merge.setXYpos(x, y_merge)

        merge_chain = merge
        previous_dot = dot

    # TECH LAYERS
    previous_dot = baseDot
    for i, layer in enumerate(tech_layers):
        x = X - (i + 1) * x_spacing
        y = Y + 200

        dot = nuke.createNode('Dot', inpanel=False)
        dot.setInput(0, previous_dot)

        shuffle = nuke.createNode('Shuffle', inpanel=False)
        shuffle['in'].setValue(layer)
        shuffle['label'].setValue('[value in]')
        shuffle.setInput(0, dot)
        shuffle.setXYpos(x, y + 100)

        snap_dot_to_node(dot, shuffle)
        dot['label'].setValue(layer)
        dot['note_font_size'].setValue(41)
        dot['note_font_color'].setValue(0xFFFFFFFF)

        previous_dot = dot

    # COPY BRANCH (correct layout)
    x_copy = X + (len(main_layers) + 3) * x_spacing

    sideDot = nuke.createNode('Dot', inpanel=False)
    sideDot.setInput(0, mainDot)
    sideDot.setXYpos(x_copy + 30, Y)  # aligned with mainDot

    copy = nuke.createNode('Copy', inpanel=False)
    copy.setInput(0, merge_chain)  # B input (background)
    copy.setInput(1, sideDot)      # A input (foreground)
    copy.setXYpos(x_copy, y_merge)

    premult = nuke.createNode('Premult', inpanel=False)
    premult.setInput(0, copy)
    premult.setXYpos(x_copy, y_merge + 100)
def snap_dot_to_node(dot_node, target_node):
    """Align the Dot exactly centered above the target node for straight lines."""
    try:
        x = target_node.xpos() + (target_node.screenWidth() // 2) - 6
    except Exception:
        x = target_node.xpos()
    y = target_node.ypos() - 120  # fixed vertical offset
    dot_node.setXYpos(x, y)

def split():
    launch_layer_split_panel()
