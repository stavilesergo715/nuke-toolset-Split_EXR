
### MenuPy 2.0 start here
menubar = nuke.menu("Nuke")
tools = menubar.addMenu("Tools")


tools.addCommand("Split EXR", "import split_EXR;split_EXR.split()")

### MenuPy 2.0 end here

